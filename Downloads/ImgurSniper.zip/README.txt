How to install manually:

Extract this .zip File into "[MainDrive]:\[ProgramFiles with Architecture]\ImgurSniper"

(For x64 Users: "C:\Program Files\ImgurSniper")

(For x32 Users: "C:\Program Files (x86)\ImgurSniper")